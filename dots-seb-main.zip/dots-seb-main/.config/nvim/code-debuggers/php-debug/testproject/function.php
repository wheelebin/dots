<?php

function a_function()
{
    echo 'hello';
    echo 'world';
    echo '!';
}

a_function();
