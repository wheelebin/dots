stdout output 1
<?php

echo 'stdout output 2';

error_log('sterr output 1');
error_log('sterr output 2');
