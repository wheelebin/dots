<?php

echo 'hello';
echo 'world';
echo '!';
