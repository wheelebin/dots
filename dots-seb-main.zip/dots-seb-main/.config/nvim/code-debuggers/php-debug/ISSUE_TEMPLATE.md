PHP version:
Xdebug version:
VS Code extension version:

Your launch.json:
Xdebug php.ini config:

Xdebug logfile (from setting `xdebug.log` in php.ini):
VS Code extension logfile (from setting `"log": true` in launch.json):

Code snippet to reproduce:

```php

```
