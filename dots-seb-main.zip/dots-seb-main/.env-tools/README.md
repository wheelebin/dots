# Dev-tools


# Run

setup readme based on dev.sh & main as well as https://www.atlassian.com/git/tutorials/dotfiles 
