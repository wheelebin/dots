const a = 123
